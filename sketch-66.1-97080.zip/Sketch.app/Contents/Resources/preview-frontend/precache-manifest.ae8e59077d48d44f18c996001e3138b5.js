self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "985228c139ae0a2f3571b7f10772a04c",
    "url": "/index.html"
  },
  {
    "revision": "ef4dddf75552c96c5795",
    "url": "/static/js/2.baa3f2f3.chunk.js"
  },
  {
    "revision": "99053ba216cea9dfbb8471265e4aa8b6",
    "url": "/static/js/2.baa3f2f3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "81607d4d8091bfabcd61",
    "url": "/static/js/main.14b14679.chunk.js"
  },
  {
    "revision": "b6000be5560a9bb4a978",
    "url": "/static/js/runtime-main.488a0ebd.js"
  },
  {
    "revision": "ca47a092c1e6a3b1cd6df18987b1d359",
    "url": "/static/media/artboard.ca47a092.svg"
  },
  {
    "revision": "a2fb0bb8ba709504787fdd92ef4a6477",
    "url": "/static/media/warning.a2fb0bb8.svg"
  }
]);